using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Threading;


namespace pinger
{
	/// <summary>
	/// 
	/// </summary>
	public class PingSite
	{
		public int consecutive_fail_count;
		public int total_pings;
		public int total_elapsed_time;
		
		public int min,max,sum,count;
		public PingSite()
		{
			// 
			// TODO: Add constructor logic here
			//
		}

		public int OnePing(IPAddress hostaddress, int delay, ushort id, ushort seq,ref TimeSpan elapsed)
		{
			// return code = 0 for OK, 1 for fail -- delay in seconds
			DateTime t1, t2;
			
			byte[] pkt, rpkt;
			int rc = 0;
			rpkt = new byte[200];  // receive packet area
			IPEndPoint hostEndPoint;
			ushort cksum;
			int ptr;
			// length of outgoing packet
			int len = 60;
			pkt = new byte[len];
			pkt[0]=8;
			pkt[1]=0;
			hostEndPoint = new IPEndPoint(hostaddress,0);
			// get a socket
			Socket s = new Socket(AddressFamily.InterNetwork,SocketType.Raw,ProtocolType.Icmp);
			// bind to a local endpoint
			IPEndPoint ipe = new IPEndPoint(0,0);
			s.Bind(ipe);
			// build the ICMP packet
			cksum = 0;
			this.SetByteWithUshort(cksum,ref pkt,2);
			this.SetByteWithUshort(id,ref pkt,4);
			this.SetByteWithUshort(seq,ref pkt,6);
			// get the current date and time
			t1 = DateTime.Now;
			// compute checksum
			this.ComputeCksum(pkt,len,ref cksum);
			this.SetByteWithUshort(cksum,ref pkt,2);
			try
			{
				// send the packet
				s.SendTo(pkt,hostEndPoint);
			}
			catch (System.Exception e)
			{
				rc=1;
			}

			// wait for the response
			
			bool stuff = s.Poll(delay * 1000000,SelectMode.SelectRead)& (rc==0);
			int rcnt;
			rc = 0;
			if(stuff)
			{
				
				try 
				{
					rcnt = s.Receive(rpkt);
					t2 = DateTime.Now;
					elapsed = t2.Subtract(t1);
				}
				catch (System.Exception e)
				{
					rc=1;  // indicate failure
				}
			}
			else
			{// set return code to indicate timeout
				rc = 1;
			}
			// set return codes

			return rc;
		}

		public void SetByteWithUshort(ushort val, ref byte[] barray, int ptr)
		{
			ushort tmpl,tmpr;
			tmpr = (ushort)(val & (ushort)0xff);
			tmpl = (ushort)((val >> 8) & (ushort)0xff);
			barray[ptr]=(byte)tmpl;
			barray[ptr+1]=(byte)tmpr;
		
		}

		public void GetUshortFromByte(ref ushort val, ref byte[] barray, int ptr)
		{
				ushort tmp, tmp2;
			uint a;
			tmp = (ushort)(barray[ptr]);
			tmp2 = (ushort)(barray[ptr+1]);
			tmp = (ushort)(tmp <<  8); 
			val =(ushort)(tmp | tmp2);
			
		
		}

		public void ComputeCksum(byte[] barray, int length, ref ushort cksum)
		{ 
			
			int sum,cnt;
			ushort tmp = 0;
			sum=0;
			int ptr = 0;
			cnt = length;
			while ( cnt > 1 )
			{
				this.GetUshortFromByte(ref tmp,ref barray,ptr);
				cnt = cnt -2;
				ptr = ptr + 2;
				sum = sum + (0xffff & tmp);
			}
			// for an odd number of bytes
			if (cnt == 1)
			{
				sum = sum + (0xff & (int)(barray[ptr]));
			}

			sum = (sum >> 16) + (sum &0xffff);
			sum = sum + (sum >> 16);
			cksum = (ushort)( ~(sum & 0xffff));
		
		}

		public int ResolveHost(string hostname, ref IPAddress address)
		{ // resolve the host address
			int rc;
			// returns 0 of OK, 1 if not resolved
			// resolve the server name
			try
			{
				IPHostEntry hostInfo = Dns.Resolve(hostname);
				IPAddress[] IPaddresses = hostInfo.AddressList;
				address = IPaddresses[0];
				rc = 0;
			}
			catch (System.Exception e)
			{
				rc = 1;
			}
			return rc;
		}
	
		public void ThreadProc()
		{
			int res;
			
			
			  TimeSpan elapsed = new TimeSpan(0);
			count=0;
			double avg;
			min=9999999;
			max=0;
			sum=0;
			count_good=0;
			count_fail=0;
			while(go)
			{
				res = this.OnePing(taddress,5,5,tseqno,  ref elapsed);
			tseqno++;
				if (res==0) 
				{
				count_good++;
				count=elapsed.Milliseconds;
				sum = sum + count ;
					if(count > max) max= count;
					if (count < min) min = count;
					
				 } 
				else
				{
				count_fail++;
				}
				Thread.Sleep(2000);
				avg = (double)sum/(double)count_good;
				bptr.textBox3.Text=count_good.ToString();
				bptr.textBox4.Text=count_fail.ToString();
			    bptr.textBox6.Text=min.ToString();
				bptr.textBox7.Text=max.ToString();
				bptr.textBox8.Text=avg.ToString();
				bptr.Invalidate();
				bptr.Update();
				
			}
		
		}

		public string tserver
		{
			get
			{
				return null;
			}
			set
			{
				tserver=value;
			}
		}

		public ushort tseqno;

		
		

		public Form1 bptr;
		public Thread mythread;
		public int count_good;
		public int count_fail;

		public IPAddress taddress;
		public bool go;
		
	}
}
