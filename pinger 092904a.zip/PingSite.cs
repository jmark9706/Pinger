using System;
using System.Net;
using System.Net.Sockets;

namespace pinger
{
	/// <summary>
	/// 
	/// </summary>
	public class PingSite
	{
		public int consecutive_fail_count;
		public int total_pings;
		public int total_elapsed_time;
		public PingSite()
		{
			// 
			// TODO: Add constructor logic here
			//
		}

		public int OnePing(IPAddress hostaddress, int delay, ushort id, ushort seq)
		{
			
			byte[] pkt, rpkt;
			rpkt = new byte[100];  // receive packet area
			IPEndPoint hostEndPoint;
			ushort cksum;
			int ptr;
			// length of outgoing packet
			int len = 60;
			pkt = new byte[len];
			pkt[0]=8;
			pkt[1]=0;
			hostEndPoint = new IPEndPoint(hostaddress,0);
			// get a socket
			Socket s = new Socket(AddressFamily.InterNetwork,SocketType.Raw,ProtocolType.Icmp);
			// bind to a local endpoint
			IPEndPoint ipe = new IPEndPoint(0,0);
			s.Bind(ipe);
			// build the ICMP packet
			cksum = 0;
			this.SetByteWithUshort(cksum,ref pkt,2);
			this.SetByteWithUshort(id,ref pkt,4);
			this.SetByteWithUshort(seq,ref pkt,6);
			// get the current date and time
			DateTime dt = DateTime.Now;
			// compute checksum
			this.ComputeCksum(pkt,len,ref cksum);
			this.SetByteWithUshort(cksum,ref pkt,2);
			// send the packet
			s.SendTo(pkt,hostEndPoint);
			// wait for the response
			
			bool stuff = s.Poll(delay * 1000000,SelectMode.SelectRead);
			int rcnt, rc;
			rc = 0;
			if(stuff)
			{
				rcnt = s.Receive(rpkt);
			}
			else
			{// set return code to indicate timeout
				rc = 1;
			}
			// set return codes

			return rc;
		}

		public void SetByteWithUshort(ushort val, ref byte[] barray, int ptr)
		{
			ushort tmpl,tmpr;
			tmpr = (ushort)(val & (ushort)0xff);
			tmpl = (ushort)((val >> 8) & (ushort)0xff);
			barray[ptr]=(byte)tmpl;
			barray[ptr+1]=(byte)tmpr;
		
		}

		public void GetUshortFromByte(ref ushort val, ref byte[] barray, int ptr)
		{ushort tmp, tmp2;
			uint a;
			tmp = (ushort)(barray[ptr]);
			tmp2 = (ushort)(barray[ptr+1]);
			tmp = (ushort)(tmp <<  8); 
			val =(ushort)(tmp | tmp2);
			
		
		}

		public void ComputeCksum(byte[] barray, int length, ref ushort cksum)
		{ 
			
			int sum,cnt;
			ushort tmp = 0;
			sum=0;
			int ptr = 0;
			cnt = length;
			while ( cnt > 1 )
			{
				this.GetUshortFromByte(ref tmp,ref barray,ptr);
				cnt = cnt -2;
				ptr = ptr + 2;
				sum = sum + (0xffff & tmp);
			}
			// for an odd number of bytes
			if (cnt == 1)
			{
				sum = sum + (0xff & (int)(barray[ptr]));
			}

			sum = (sum >> 16) + (sum &0xffff);
			sum = sum + (sum >> 16);
			cksum = (ushort)( ~(sum & 0xffff));
		
		}

		public int ResolveHost(string hostname, ref IPAddress address)
		{ // resolve the host address
			int rc;
			// returns 0 of OK, 1 if not resolved
			// resolve the server name
			try
			{
				IPHostEntry hostInfo = Dns.Resolve(hostname);
				IPAddress[] IPaddresses = hostInfo.AddressList;
				address = IPaddresses[0];
				rc = 0;
			}
			catch (System.Exception e)
			{
				rc = 1;
			}
			return rc;
		}

		public void ThreadProc()
		{
		
		}
	}
}
